// functions/api/log-usage.js
// El análisis del texto corre en el navegador (sin IA), así que esta función
// solo registra CUÁNDO un estudiante generó un análisis, para las estadísticas.

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.GRFA_KV) {
    return json({ error: "Falta enlazar el namespace de KV 'GRFA_KV' en la configuración de Cloudflare Pages." }, 500);
  }

  let studentId;
  try {
    const body = await request.json();
    studentId = body.studentId;
  } catch (e) {
    return json({ error: "Cuerpo de la solicitud inválido." }, 400);
  }

  if (!studentId) {
    return json({ error: "Falta studentId." }, 400);
  }

  try {
    const usageKey = "usage:" + studentId;
    const existing = await env.GRFA_KV.get(usageKey);
    const log = existing ? JSON.parse(existing) : [];
    log.push(new Date().toISOString());
    while (log.length > 200) log.shift();
    await env.GRFA_KV.put(usageKey, JSON.stringify(log));
    return json({ ok: true });
  } catch (err) {
    return json({ error: "No se pudo registrar el uso: " + err.message }, 500);
  }
}
