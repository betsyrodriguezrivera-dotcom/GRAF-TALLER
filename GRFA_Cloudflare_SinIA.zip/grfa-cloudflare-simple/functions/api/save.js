// functions/api/save.js
// Guarda el registro de un ciclo de un estudiante en Cloudflare KV.

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.GRFA_KV) {
    return json({ error: "Falta enlazar el namespace de KV 'GRFA_KV' en la configuración de Cloudflare Pages." }, 500);
  }

  let payload;
  try {
    payload = await request.json();
  } catch (e) {
    return json({ error: "Cuerpo de la solicitud inválido." }, 400);
  }

  const { studentId, ciclo, data } = payload || {};
  if (!studentId || !ciclo || !data) {
    return json({ error: "Faltan datos para guardar (studentId, ciclo o data)." }, 400);
  }

  const key = `record:${studentId}:${ciclo}`;
  try {
    await env.GRFA_KV.put(key, JSON.stringify(data));
    return json({ ok: true, key });
  } catch (err) {
    return json({ error: "No se pudo guardar en KV: " + err.message }, 500);
  }
}
