// functions/api/tutor.js
// Devuelve todos los registros guardados, agrupados por estudiante, para el panel del tutor.

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export async function onRequestGet(context) {
  const { env } = context;

  if (!env.GRFA_KV) {
    return json({ error: "Falta enlazar el namespace de KV 'GRFA_KV' en la configuración de Cloudflare Pages." }, 500);
  }

  try {
    const list = await env.GRFA_KV.list({ prefix: "record:" });
    const byStudent = {};

    for (const item of list.keys) {
      const value = await env.GRFA_KV.get(item.name);
      if (!value) continue;
      const data = JSON.parse(value);
      const parts = item.name.split(":"); // record : studentId : ciclo
      const sid = parts[1];
      if (!byStudent[sid]) byStudent[sid] = { nombre: data.nombre, curso: data.curso, ciclos: {} };
      byStudent[sid].ciclos[data.ciclo] = data;
    }

    return json({ students: byStudent });
  } catch (err) {
    return json({ error: "No se pudieron cargar los registros: " + err.message }, 500);
  }
}
