// functions/api/stats.js
// Devuelve el registro de uso y los ciclos guardados de UN estudiante (para su propia vista de estadísticas).
// Se consulta con GET /api/stats?studentId=xxxx

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export async function onRequestGet(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const studentId = url.searchParams.get("studentId");

  if (!studentId) {
    return json({ error: "Falta el parámetro studentId." }, 400);
  }
  if (!env.GRFA_KV) {
    return json({ error: "Falta enlazar el namespace de KV 'GRFA_KV' en la configuración de Cloudflare Pages." }, 500);
  }

  try {
    const usageRaw = await env.GRFA_KV.get("usage:" + studentId);
    const usage = usageRaw ? JSON.parse(usageRaw) : [];

    const records = {};
    for (const ciclo of ["1", "2", "3"]) {
      const raw = await env.GRFA_KV.get("record:" + studentId + ":" + ciclo);
      if (raw) records[ciclo] = JSON.parse(raw);
    }

    return json({ usage, records });
  } catch (err) {
    return json({ error: "No se pudieron cargar las estadísticas: " + err.message }, 500);
  }
}
