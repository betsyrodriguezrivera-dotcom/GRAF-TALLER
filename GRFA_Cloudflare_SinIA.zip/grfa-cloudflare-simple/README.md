# GRFA — Versión sin IA, con estadísticas y panel del tutor compartidos

Esta versión analiza el texto por **reglas** (conectores, marcadores de
argumentación, citas APA, estructura de párrafos) directamente en el
navegador del estudiante — **no llama a ninguna IA, no necesita clave de
ningún tipo**.

Lo único que usa un servidor es lo que **debe** ser compartido entre
dispositivos: el guardado de progreso, "Mis estadísticas" y el "Panel del
tutor". Para eso usa **Cloudflare Pages + KV**, gratis y sin tarjeta.

## Estructura

```
grfa-cloudflare-simple/
├── wrangler.toml
├── public/
│   └── index.html            ← la app (análisis 100% local; guarda vía /api/*)
└── functions/
    └── api/
        ├── save.js            ← guarda el progreso de un estudiante en KV
        ├── stats.js           ← estadísticas de uso y avance de UN estudiante
        ├── tutor.js           ← lista todos los registros para el tutor
        └── log-usage.js       ← registra cada vez que se generó un análisis
```

## Pasos para desplegar

### 1. Crea una cuenta gratuita en Cloudflare
https://dash.cloudflare.com/sign-up — solo correo y contraseña, sin tarjeta.

### 2. Crea el namespace de KV
`Workers & Pages → KV → Create a namespace` → nómbralo, por ejemplo, `grfa-kv`.
Copia el ID y pégalo en `wrangler.toml`, reemplazando
`REEMPLAZA_CON_TU_KV_NAMESPACE_ID`.

### 3. Sube el proyecto a GitHub
Crea un repositorio con esta carpeta completa y súbelo.

### 4. Crea el proyecto en Cloudflare Pages
`Workers & Pages → Create → Pages → Connect to Git` → selecciona tu
repositorio.
- Build command: (vacío)
- Build output directory: `public`

### 5. Enlaza el KV namespace
Dentro del proyecto: `Settings → Functions → KV namespace bindings` →
`Add binding`:
- Variable name: `GRFA_KV`
- KV namespace: el creado en el paso 2

### 6. Redeploy
`Deployments → Retry deployment` para que tome el binding.

### 7. Prueba
Abre la URL pública (`tu-proyecto.pages.dev`):
- Pega un texto y genera el análisis (instantáneo, sin esperar a ningún servidor externo).
- Completa la matriz y usa "Guardar mi progreso".
- Revisa "Mis estadísticas" y el "Panel del tutor" — ya deberían verse igual
  desde cualquier computador o celular.

## Ventajas de esta versión frente a las que usan IA

- **Cero configuración de claves.** No hay Anthropic, no hay Gemini, nada que
  vencer ni que se agote por límite de uso.
- **Análisis instantáneo**, no depende de la conexión del estudiante en ese
  momento (el guardado sí necesita internet, el análisis no).
- Más fácil de mantener: solo un namespace de KV, sin variables de entorno
  de terceros.

## Limitación a tener en cuenta

Como el análisis es por reglas (cuenta conectores, marcadores, citas), no
"entiende" el texto como lo haría un modelo de lenguaje. Es un buen primer
filtro y una forma de generar el hábito de autorrevisión, pero no reemplaza
la lectura crítica del docente.
